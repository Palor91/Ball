namespace WildBall.Inputs
{
    public class GlobalStringVars
    {
        #region Inout Vars

        public const string HORIZANTAL_AXIS = "Horizontal";
        public const string VERTICAL_AXIS = "Vertical";
        public const string JUMP_BUTTON = "Jump";
        public const string MOUSE_X = "Mouse X";
        public const string MOUSE_Y = "Mouse Y";
    }

    #endregion
}